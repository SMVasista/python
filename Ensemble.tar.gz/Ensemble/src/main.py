import sys, os, csv, copy, pickle
import cwgutils, mathutils

def parseDatapoints(rdatafile):
#Element data-structure
#    mainDict: {
#        element:{
#            response: "R/N"
#            co-ordinates:[] "dimensions"
#            }
#        }	
	dataPts = cwgutils.readLinesAndSplit(rdatafile, ' ')
	keylist = []
	arraylist = []
	for element in dataPts:
		key, array = cwgutils.reHeadArray(element)
		keylist.append(key)
		arraylist.append(array)
	labelDict = dict(zip(keylist, arraylist))
	return labelDict

def processData(labeldict):
	calibratedDict, medianPoints = mathutils.calibrateDataset(labeldict)
	medianVectors = mathutils.createPointVectors(medianPoints)
	coEff, c = mathutils.createHyperPlane(medianVectors)
	return calibratedDict, medianPoints, coEff, c

def testEnsemble(medianPts, coEff, c, testfile, uT):
	labelTDict = parseDatapoints(testfile)
	Prediction = {}

	for element in labelTDict:
		dimLength = len(labelTDict[element]) - 1

	Prediction['ENSEMBLE'] = {}
	for element in labelTDict:
		val = 0.0
		for i in range(1,len(labelTDict[element])):
			val += float(coEff[i-1])*(float(labelTDict[element][i]))
		if val > float(c):
			Prediction['ENSEMBLE'][element] = 'R'
		elif val < float(c):
			Prediction['ENSEMBLE'][element] = 'N'
		else:
			Prediction['ENSEMBLE'][element] = 'A'
		#print Prediction['ENSEMBLE'][element], labelTDict[element][0]

	for i in range(dimLength):
		keyname = 'model'+str(i+1)
		Prediction[keyname] = {}
		for element in labelTDict:
			if float(labelTDict[element][i+1]) > float(medianPts[i]):
				Prediction[keyname][element] = 'R'
			elif float(labelTDict[element][i+1]) < float(medianPts[i]):
				Prediction[keyname][element] = 'N'
			else:
				Prediction[keyname][element] = 'A' 

	Statistics = {}

	for model in Prediction:
		Statistics[model] = 0.0
		for element in labelTDict:
			if labelTDict[element][0] != None:
				if Prediction[model][element] == labelTDict[element][0]:
					Statistics[model] += 1.0
		Statistics[model] = Statistics[model] / len(labelTDict)
		print model,":", Statistics[model]*100, "%"

	return None
		
			
		
if __name__=="__main__":
	script, dataFile, testFile = sys.argv
	labelDict = parseDatapoints(dataFile)
	calibDict, medianPts, coEff, c = processData(labelDict)
	print 'mu_xi: ', medianPts, 'co-efficient: ', coEff, '(n X r_o): ', c
	print '\n'
	testEnsemble(medianPts, coEff, c, testFile, 1)

