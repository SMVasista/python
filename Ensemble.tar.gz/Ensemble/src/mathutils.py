from __future__ import division
import math as mt
import numpy as NP
import re, copy, random, itertools, numbers
import cwgutils

#Binary Classifier
#OutCome = ['R', 'N']

def calibrateDataset(labelDict):
#Element data-structure
#    mainDict: {
#        element:[
#            0: "R/N"
#            1..n:[] "dimensions"
#            ]
#        }
#dimension = len(mainDict[element][co-ordinates])
	coordMedian = []
	caliblDict = {}
	for element in labelDict:
		dimLength = len(labelDict[element])
		for i in range(1, len(labelDict[element])):
			labelDict[element][i] = float(labelDict[element][i])

	for i in range(1,dimLength):
		prdArray = []
		nrdArray = []
		prdConsArray = []
		nrdConsArray = []
		for element in labelDict:
			if labelDict[element][0] != None:
				if labelDict[element][0] == 'R':
					prdArray.append(labelDict[element][i])
				elif labelDict[element][0] == 'N':
					nrdArray.append(labelDict[element][i])
			else:
				exit(0)
		for val in prdArray:
			if abs(val - NP.mean(prdArray)) < NP.std(prdArray):
				prdConsArray.append(val)
		for val in nrdArray:
			if abs(val - NP.mean(nrdArray)) < NP.std(nrdArray):
				nrdConsArray.append(val)

		mu = (max(nrdConsArray) + min(prdConsArray)) / 2

		coordMedian.append(mu)

	for i in range(1,dimLength):
		for element in labelDict:
			labelDict[element][i] = (labelDict[element][i] - coordMedian[i-1])

	modifiedLabelDict = copy.deepcopy(labelDict)
	return modifiedLabelDict, coordMedian

def createPointVectors(coordmedian):
	coordList = []
	dimLen = len(coordmedian)
	for i in range(dimLen):
		p = []
		for elem in coordmedian:
			if coordmedian.index(elem) == i:
				p.append(0)
			else:
				p.append(elem)
		coordList.append(p)
	return coordList
			
def createHyperPlane(coordlist):
	#Creating N-1 vectors on the hyperplane
	vectorList = []
	for i in range(1,len(coordlist)):
		V = []
		for j in range(len(coordlist[i])):
			V.append(coordlist[i-1][j] - coordlist[i][j])
		vectorList.append(V)
	
	#Calculating normal vector
	dimLen = (len(vectorList) + 1)
	head = []
	for i in range(dimLen):
		head.append('##'+str(i+1)+'##')
	B = NP.array(head)
	for vector in vectorList:
		B = NP.append(B, vector)
	B = B.reshape(dimLen, dimLen)
	print  B
	print '\n'
	
	#Calculating determinants through first-row elements
	mxList = []
	for i in range(dimLen):
		newMx = []
		for j in range(dimLen):
			for k in range(dimLen):
				if j != 0 and k != (i):
					newMx.append(B[j,k])
		newMx = NP.array(newMx)
		newMx = newMx.reshape(dimLen-1, dimLen-1)
		newMx = NP.matrix(newMx, dtype="float")
		mxList.append(newMx)

	normComp = []
	for i in range(dimLen):
		print mxList[i]
		Det = NP.linalg.det(mxList[i])
		print '\n'
		normComp.append((Det*(-1)**(i)))# Since we are taking determinant from first row => [ +, -, +, - ... ]

	#Calculating RHS
	c = NP.dot(normComp, coordlist[0])

	coefficients = []
	for i in range(len(normComp)):
		coefficients.append(float(normComp[i]))

	return coefficients, c


