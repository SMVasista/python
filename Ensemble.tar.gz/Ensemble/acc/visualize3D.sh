exists1=$(ls | grep -c -w "cluster.dat")
if [ $exists1 -gt 0 ]; then
	printf "#!/usr/bin/gnuplot\nunset key\nset datafile separator \" \"\nset object rectangle from screen 0,0 to screen 1,1 behind fillcolor rgb 'white' fillstyle solid noborder\nset grid\nset style fill transparent solid 0.5\nset style circle radius 0.5\nset palette model RGB defined ( 0 'orange', 1 'dark-blue' )\nif (!exists(\"filename\")) filename='default.dat'\nsplot \"cluster.dat\" u 5:6:7:( \$8 == 0 ? 0 : 1 ) with circles palette lw 5, (-1/$3)*($1 * x + $2 * y + $4) lc rgb 'grey' w pm3d\npause -1\n" > scatterplot.plg && gnuplot -e 'filename="cluster.dat"' scatterplot.plg
else
	echo "File not found"
fi
