import sys, os
import json
import argparse
import copy
import time
from pathlib import Path
from sets import Set

import cwgutils
import cwgpatient


# diff is the difference between currProbableResponse and threshold

def optimizePathwayWeightagePA(patientPathways, pathwaysForDrug, beta, skew, patientResponse):
    if beta == 1:
        return

    for pathway in patientPathways:
        if pathway in pathwaysForDrug:
            if pathwaysForDrug[pathway] >= 0.1 and pathwaysForDrug[pathway] < 0:
                pathwaysForDrug[pathway] = 0.1
            elif pathwaysForDrug[pathway] <= 0.1 and pathwaysForDrug[pathway] > 0:
                pathwaysForDrug[pathway] = -0.1

            if skew < 0 and patientResponse == 'R':
                if patientPathways[pathway] > 0 and pathwaysForDrug[pathway] > 0:
                    pathwaysForDrug[pathway] = pathwaysForDrug[pathway] * (1.25* float(1 + abs(skew)))
                elif patientPathways[pathway] > 0 and pathwaysForDrug[pathway] < 0:
                    pathwaysForDrug[pathway] = pathwaysForDrug[pathway] / (1.1 * float(1 + abs(skew)))
                elif patientPathways[pathway] < 0 and pathwaysForDrug[pathway] > 0:
                    pathwaysForDrug[pathway] = pathwaysForDrug[pathway] / (1.1 * float(1 + abs(skew)))
                elif patientPathways[pathway] < 0 and pathwaysForDrug[pathway] < 0:
                    pathwaysForDrug[pathway] = pathwaysForDrug[pathway] * (1.25* float(1 + abs(skew)))
            elif skew > 0 and patientResponse == 'N':
                if patientPathways[pathway] > 0 and pathwaysForDrug[pathway] > 0:
                    pathwaysForDrug[pathway] = pathwaysForDrug[pathway] / (1.1 * float(1 + abs(skew)))
                elif patientPathways[pathway] > 0 and pathwaysForDrug[pathway] < 0:
                    pathwaysForDrug[pathway] = pathwaysForDrug[pathway] * (1.25 * float(1 + abs(skew)))
                elif patientPathways[pathway] < 0 and pathwaysForDrug[pathway] > 0:
                    pathwaysForDrug[pathway] = pathwaysForDrug[pathway] * (1.25 * float(1 + abs(skew)))
                elif patientPathways[pathway] < 0 and pathwaysForDrug[pathway] < 0:
                    pathwaysForDrug[pathway] = pathwaysForDrug[pathway] / (1.1 * float(1 + abs(skew)))                        

def optimizePathwayWeightageHyp(patientPathways, pathwaysForDrug, beta, skew, patientResponse):
    if beta == 1:
        for pathway in patientPathways():
            if pathway in pathwaysForDrug:
                if skew < 0 and patientResponse == 'N':
                    if patientPathways[pathway] > 0 and pathwaysForDrug[pathway] > 0:
                        pathwaysForDrug[pathway] = pathwaysForDrug[pathway] * (1.25 * float(1 + abs(skew)))
                    elif patientPathways[pathway] > 0 and pathwaysForDrug[pathway] < 0:
                        pathwaysForDrug[pathway] = pathwaysForDrug[pathway] / (1.25 * float(1 + abs(skew)))
                    elif patientPathways[pathway] < 0 and pathwaysForDrug[pathway] > 0:
                        pathwaysForDrug[pathway] = pathwaysForDrug[pathway] / (1.25 * float(1 + abs(skew)))
                    elif patientPathways[pathway] < 0 and pathwaysForDrug[pathway] < 0:
                        pathwaysForDrug[pathway] = pathwaysForDrug[pathway] * (1.25 * float(1 + abs(skew)))
                elif skew > 0 and actualResponse == 'R':
                    if patientPathways[component] > 0 and pathwaysForDrug[component] > 0:
                        pathwaysForDrug[component] = pathwaysForDrug[component] / (1.25 * float(1 + abs(skew)))
                    elif patientPathways[component] > 0 and pathwaysForDrug[component] < 0:
                        pathwaysForDrug[component] = pathwaysForDrug[component] * (1.25 * float(1 + abs(skew)))
                    elif patientPathways[component] < 0 and pathwaysForDrug[component] > 0:
                        pathwaysForDrug[component] = pathwaysForDrug[component] * (1.25 * float(1 + abs(skew)))
                    elif patientPathways[component] < 0 and pathwaysForDrug[component] < 0:
                        pathwaysForDrug[component] = pathwaysForDrug[component] / (1.25 * float(1 + abs(skew)))    
    elif beta == -1:
        for pathway in patientPathways:
            if pathway in pathwaysForDrug:
                if pathwaysForDrug[pathway] > -0.1 and pathwaysForDrug[pathway] < 0:
                    pathwaysForDrug[pathway] = 0.1
                elif pathwaysForDrug[pathway] < 0.1 and pathwaysForDrug[pathway] > 0:
                    pathwaysForDrug[pathway] = -0.1

                if skew < 0 and actualResponse == 'N':
                    if patientPathways[pathway] > 0 and pathwaysForDrug[pathway] > 0:
                        pathwaysForDrug[pathway] = pathwaysForDrug[pathway] * (1.25 * float(1 + abs(skew)))
                    elif patientPathways[pathway] > 0 and pathwaysForDrug[pathway] < 0:
                        pathwaysForDrug[pathway] = pathwaysForDrug[pathway] / (1.1 * float(1 + abs(skew)))
                    elif patientPathways[pathway] < 0 and pathwaysForDrug[pathway] > 0:
                        pathwaysForDrug[pathway] = pathwaysForDrug[pathway] / (1.1 * float(1 + abs(skew)))
                    elif patientPathways[pathway] < 0 and pathwaysForDrug[pathway] < 0:
                        pathwaysForDrug[pathway] = pathwaysForDrug[pathway] * (1.25 * float(1 + abs(skew)))
                elif skew > 0 and actualResponse == 'R':
                    if patientPathways[pathway] > 0 and pathwaysForDrug[pathway] > 0:
                        pathwaysForDrug[pathway] = pathwaysForDrug[pathway] / (1.1 * float(1 + abs(skew)))
                    elif patientPathways[pathway] > 0 and pathwaysForDrug[pathway] < 0:
                        pathwaysForDrug[pathway] = pathwaysForDrug[pathway] * (1.25 * float(1 + abs(skew)))
                    elif patientPathways[pathway] < 0 and pathwaysForDrug[pathway] > 0:
                        pathwaysForDrug[pathway] = pathwaysForDrug[pathway] * (1.25 * float(1 + abs(skew)))
                    elif patientPathways[pathway] < 0 and pathwaysForDrug[pathway] < 0:
                        pathwaysForDrug[pathway] = pathwaysForDrug[pathway] / (1.1 * float(1 + abs(skew)))                        


def testPatientResponse(patients, patientResponse, patientMsource, scoresDir, trainingDir, pathwaysForDrug, xThresh, yThresh):
    predictionDir = os.path.join(pwd, 'PredictionData')

    cwg.mkpdir(predictionDir)
    predFile = open(os.path.join(predictionDir, 'cluster.dat'), 'w')


    # if len(holderPatients.keys()) == 0:
        # patientNames = cwg.readLines(os.path.join(trainingDir, '.kbplist'))
        # for name in patientNames:
            # holderPatients[name] = pickleLoad(trainingDir, name + '.clf')


    kbpFile = open(os.path.join(trainingDir, '.kbplist'), 'a')
    testPatientResponseProbability = cwgutils.arrayToDict(patients, 0.0)
    testPatientCausalDepth = cwgutils.arrayToDict(patients, 0)
    predictedResponse = {}

    nDrug = len(pathwaysForDrug)
    profiles = {}

    for patientName in patients:
        profile = cwgpatient.loadPatientProfile(patientname, os.path.join(scoresDir, 'list'), patientMsource[patientName])
        profile = cwgpatient.genPathwaysSignature(profile, scoresDir, trainingDir)
        profile["response"] = patientResponse[patientName]["response"]
        pathways = pickleLoad(os.path.join(predictionDir, patientName))

        nPatient = len(pathways)
        for pathway in pathways.keys():
            if pathway in pathwaysForDrug:
                testPatientResponseProbability[patientName] += float((2 / nPatient) * (2 / nDrug) * pathwaysForDrug[pathway] * pathways[pathway])

        if testPatientResponseProbability[patientName] > xThresh:
            predictedResponse[patientName] = 'R'
        elif testPatientResponseProbability[patientName] <= yThresh:
            predictedResponse[patientName] = 'N'

        if patientName not in holderPatients.keys():
            holderPatients[patientName] = profile

        if len(profile["pathwaysmap"].keys()) > 2:
            testPatientCausalDepth[patientName] = clusterPatient(profile)

        # suffix = (response == None) ? '' : (response == 'R') ? '1' : '0'
        suffix = '' if profile["response"] == None else '1' if profile["response"] == 'R' else '0'
        ss = patientName + ' ' + ('10.2f' % (testPatientResponseProbability[patientname] - xThresh)) + ' ' + ('%02d' % testPatientCausalDepth[patientName])
        if len(suffix):
            ss = ss + ' ' + suffix
        predFile.write(ss + '\n')

        diff = testPatientResponseProbability[patientname] - xThresh
        if update_mode == 0:
            continue
        elif update_mode == 1:
            if profile["response"] != None:
                if predictedResponse[patientName] == profile["response"]:
                    optimizePathwayWeightagePA(pathways, pathwaysForDrug, 1, diff, profile["response"])
                else:
                    optimizePathwayWeightagePA(pathways, pathwaysForDrug, -1, diff, profile["response"])
            else:
                pass
        elif update_mode == 2:
            if profile["response"] != None:
                if predictedResponse[patientName] == profile["response"]:
                    OptimizePathwayWeightageHyp(pathways, pathwaysForDrug, 1, diff, profile["response"])
                else:
                    OptimizePathwayWeightageHyp(pathways, pathwaysForDrug, -1, diff, profile["response"])
            else:
                pass

        if patientName not in patientNames:
            pickleDump(os.path.join(trainingDir, patientName + '.clf'))
            kbpFile.write(patientName + '\n')

    return predictedResponse



trainingPatientList = {}
calibPatientList = {}
testPatientList = {}
drugPathways = {}
drugList = {}
thresholds = {}
predictions = {}

# assumption is that test patient are present in drug_pathways table, however, response is
# to be predicted
def  predictResponse():
    for drugName, patientObj in drugList.iteritems():
        pathwaysForDrug = drugPathways[drugName]
        nDrug = len(pathwaysForDrug)
        xThresh = thresholds[drugName]["xthreshold"]
        yThresh = thresholds[drugName]["ythreshold"]

        respProbalility = cwgutils.arrayToDict(testPatientList.keys(), 0.0)
        causalDepth = cwgutils.arrayToDict(testPatientList.keys(), 0)
        pred = None
        
        for testPatient in testPatientList:
            testPathways = patientObj[testPatient]["pathways"]
            nPathways = len(testPathways)

            for pName in testPathways:
                if pName in drugPathways[drugName]:
                    respProbablity[testPatient] += float((2 / nPathways) * (2 / nDrug) * pathwaysForDrug[pName] * testPathways[pName]["score"])

            if respProbablity[testPatient] > xThresh:
                pred = 'R'
            elif respProbablity[testPatient] <= yThresh:
                pred = 'N'

            if len(patientObj[testPatient]["pathwaysmap"]) > 2:
                causalDepth[testpatient] = clusterPatient(patientObj, testPatient)

            diff = respProbablity[testPatient] - xThresh

            if update_mode == 0:
                continue
            elif update_mode == 1:
                if pred != None:
                    if pred == patientObj[testPatient]["response"]:
                        optimizePathwayWeightagePA(testPathways, drugPathways, 1, diff, patientObj[testPatient]["response"])
                    else:
                        optimizePathwayWeightagePA(testPathways, drugPathways, -1, diff, patientObj[testPatient]["response"])
                else:
                    pass
            elif update_mode == 2:
                if pred != None:
                    if pred == patientObj[testPatient]["response"]:
                        optimizePathwayWeightageHyp(testPathways, drugPathways, 1, diff, patientObj[testPatient]["response"])
                    else:
                        optimizePathwayWeightageHyp(testPathways, drugPathways, -1, diff, patientObj[testPatient]["response"])
                else:
                    pass

            if drugName not in predictions:
                predictions[drugName] =  { testPatient: pred }
            else:
                predictions[drugName][testPatient] =  pred

    return predictions


def readPatients(cursor, patientIds):
    patientList = [ '"' + patientId + '"' for patientId in patientIds]
    rows = DbUtils.query(cursor, 'SELECT PATIENT_ID,GENE_NAME,GENE_MUTATION FROM PATIENT_GENES_DATA WHERE PATIENT_ID IN (' + ','.join(patientList) + ')')
    print len(rows), rows[0]

    patients = {}
    for row in rows:
        patientId, gene, mutation = row["PATIENT_ID"], row["GENE_NAME"], row["GENE_MUTATION"]

        if not patientId in patients:
            patients[patientId] = { gene: mutation }
        else:
            patients[patientId][gene] = mutation
    return patients


# the resulting structure is like
# {
#    <drug-1> : {
#         <patient-1>: {
#            "response": <response>
#            "pathways": {
#               <pathway-1>: { 'weightage': <weightage-1>, "score": <some-value>,
#                              <gene-1>: { 'lof': <lof-score>, 'gof': <gof-score> },
#                              <gene-2>: { 'lof': <lof-score>, 'gof': <gof-score> },
#                              ...
#                            }
#               ...
#            }
#         },
#         ...
#   },
#   ...
# }

def readDrugs(cursor, drugNames):
    drugs = {}
    drugNameList = [ '"' + drugName + '"' for drugName in drugNames]
    patientNames = trainingPatientList.keys() + testPatientList.keys()
    patientNames = [ '"' + patientName + '"' for patientName in patientNames]

    query = 'SELECT a.DRUG_NAME  AS DRUG_NAME, '  + \
                   'a.PATIENT_ID AS PATIENT_ID, ' + \
                   'b.PATHWAY_NAME AS PATHWAY_NAME, ' + \
                   'b.PATHWAY_WEIGHTAGE AS PATHWAY_WEIGHTAGE, ' + \
                   'a.ACTUAL_RESPONSE AS RESPONSE FROM ' + \
            '(SELECT ID, DRUG_NAME, PATIENT_ID, ACTUAL_RESPONSE FROM ' + \
            ' DRUG_PATIENT_DATA WHERE DRUG_name IN (' +  ','.join(drugNameList) + ') AND ' + \
            ' PATIENT_ID IN (' + ','.join(patientNames) + ') a JOIN' + \
            '(SELECT DP_ID, PATHWAY_NAME, PATHWAY_WEIGHTAGE FROM DRUG_PATIENT_PATHWAY) b' + \
            'ON a.ID=b.DP_ID'
    rows = DbUtils.query(cursor, query)
    print len(rows), rows[0]

    # the db query above fetches patientIds and associated pathways for each drug. Pathway weightage is a placeholder for now - to be used in future
    # for categoriaztion

    for row in rows:
        drugName    = row["DRUG_NAME"]
        patientId   = row["PATIENT_ID"]
        pathwayName = row["PATHWAY_NAME"]
        pathwayWt   = row["PATHWAY_WEIGHTAGE"]
        response    = row["RESPONSE"]

        # score is initialized to 0 here, and score is used later to compute pathwaysmap, which is a smaller subset of pathways

        if not drugName in drugs:
            drug[drugName] = { patientId: { "pathways": { pathwayName: { "weightage": pathwayWt, "score": 0.0 }}, "response": response } }
        elif not patientId in drug[drugName]:
            drug[drugName][patientId] = { "pathways": { pathwayName: { "weightage": pathwayWt, "score": 0.0 }}, "response": response }
        else:
            drug[drugName][patientId]["pathways"][pathwayName] = { "weightage": pathwayWt, "score": 0.0 }

        # for each pathway, get the genes with associated lof/gof score
        qry = 'SELECT GENE_NAME, sum(LOF_SCORE) AS LOF_SCORE, sum(GOF_SCORE) AS GOF_SCORE FROM GENE_PATHWAY_SCORE WHERE PATHWAY_NAME="' + \
              pathwayName + '" GROUP BY GENE_NAME'
        gRows = DbUtils.query(cursor, qry)

        for gRow in gRows:
            gene = gRow["GENE_NAME"]
            lofScore = gRow["LOF_SCORE"]
            gofScore = gRow["GOF_SCORE"]
            drug[drugName][patientId]["pathways"][pathwayName][gene] = { "lof": lofScore, "gof": gofScore }


    # once the above information is fully read and transformed into an object, compute pathways for drug as well as
    # patwaymap - a restricted set of pathways for the drug for computation purposes

    for drugName,patientObjs in drugs.iteritems():
        drugPathways[drugName] = {}

        for patientId, patientObj in patientObjs.iteritems():
            trngPatient = trainingPatientList[patientId]
            for pName,pathwayObj in patientObj["pathways"].iteritems():
                if not pName in drugs["pathways"]:
                    drugPathways[drugName][pName] = 0.2 if patientObj["response"] == R else -0.2
                else:
                    drugPathways[drugName][pName] += (0.2 if patientObj["response"] == R else -0.2)

                for gene, mutation in trngPatient.iteritems():
                    if gene in pathwayObj and pathwayObj[gene]["gof"] > 0.0:
                        pathwayObj["score"] += pathwayObj[gene]["gof"]
                    elif gene in pathwayObj and pathwayObj[gene]["lof"] > 0.0:
                        pathwayObj["score"] -= pathwayObj[gene]["lof"]

            patientObj["pathwaysmap"] = cwgutils.filter(patientObj["pathways"], lambda x: x["score"] >= 0.5 or x["score"] <= -0.5)


        noise = reduce(lambda a,b: 1.0 * len(a.pathways) + len(b.pathways), patientObjs)/len(patientObjs)
        drugPathways[drugName] = cwgutils.filter(drugPathways[drugName], lambda val: (val >= 0.022*noise or val <= -0.016*noise))

    return drugs

def clusterPatient(patientObj, patientName):
    prevSubset = patientObj.keys()
    pMap = patientObj[patientName]["pathwaysmap"]

    for pathway in pMap:
        currSubset = [patient for patient in prevSubset if  pathway in patientObj[patient]["pathwaysmap"] and pMap["score"] * patientObj[patient]["pathwaysmap"][pathway]["score"] > 0]
        if (len(currSubset) > 0):
            prevSubSet = currSubset
        else:
            break

    score = 0
    similarity = []
    for patient in prevSubSet:
        score += (1 if patientObj[patient]["response"] == 'R' else -1 if patientObj[patient]["response"] == 'N' else 0)
        if len(patientObj[patient]["pathwaysmap"]) > len(pMap):
            update_score = float(score*len(patientObj[patient]["pathwaysmap"])/(0.01+len(pMap)))
            similarity.append(update_score)
        
    return score

def calibrateResponseCoefficients():
    for drugName, patientObj in drugList.iteritems():
        pathwaysForDrug = drugPathways[drugName]
        nDrug = len(pathwaysForDrug)

        responseProbability = cwgutils.arrayToDict(calibPatientList.keys(), 0.0)
        causalDepth         = cwgutils.arrayToDict(calibPatientList.keys(), 0)

        for calibPatient in calibPatientList:
            patientPathways = patientObj[calibPatient]["pathways"] 
            nPathways = len(patientPathways)

            for pName, pValue in pathwaysForDrug.iteritems():
                if pValue != 0:
                    responseProbability[calibPatient] += ((2.0 / nPathways) * (2.0 / nDrug) * pValue * patientPathways[drugPath]["score"])

            if (("pathwaysmap" in patientObj[calibPatient]) and len(patientObj[calibPatient]["pathwaysmap"]) > 2):
                causalDepth[calibPatient] = clusterPatient(patientObj, calibPatient)

        predictedResponse = {}
        accuracy = {}

        PCRList = [float(responseProability[pName]) for pName in calibPatients if patientObj[pName]["response"] == 'R']
        PARList = [float(causalDepth[pName]) for pName in calibPatients if patientObj[pName]["response"] == 'R']
        NCRList = [float(responseProability[pName]) for pName in calibPatients if patientObj[pName]["response"] == 'N']
        NARList = [float(causalDepth[pName]) for pName in calibPatients if patientObj[pName]["response"] == 'N']

        pcr = sum(PCRList) / len(PCRList)
        par = sum(PARList) / len(PARList)
        ncr = sum(NCRList) / len(NCRList)
        nar = sum(NARList) / len(NARList)

        xThresh = 0.5 * (min(PCRList) + max(NCRList))
        yThresh = 0.5 * (par + nar)

        thresholds[drugName] = { "xthresh": xThresh, "ythresh": yThresh }

def parseArgs():
    parser = argparse.ArgumentParser(description='iCOG Execution...')
    parser.add_argument('-t', '--trainingfile', type=str, help='File containing patient list with response for training the program', required=True)
    parser.add_argument('-c', '--calibration', type=str, help='File containing patient list with response for calibration', required=True)
    parser.add_argument('-e', '--testfile', type=str, help='File containing patient list for which prediction output is to be computed', required=True)
    parser.add_argument('-d', '--drugfile', type=str, help='File containing drug input', required=True)

    # print help if program is called without arguments
    if len(sys.argv) == 1:
        sys.argv.append('-h') 

    return parser.parse_args()

if __name__ == '__main__':

    # Each drug in drug list will have associated list of patients for training, calibration, and test
    # the training file given at the beginning should contain the union of all these so that they do not
    # need to be loaded again and again

    # these files should containg only the patient ids one on each line, calibration patients must be subset of training patients

    trainingPatients = cwgutils.readLines(args.trainingfile)
    calibPatients = cwgutils.readLines(args.calibration)
    testPatients  = cwgutils.readLines(args.testfile)
    drugNames = cwgutils.readLines(args.drugfile)

    # make sure calibration patients are proper subset of training patients
    if not Set(calibPatients).issubset(Set(trainingPatients)):
        print "calibration patients must be subset of training patients", list(Set(calibPatients).difference(Set(trainingPatients)))
    
    # and test patients are not part of training patients
    if Set(testPatients).issubset(Set(trainingPatients)):
        print "test patients must not be subset of training patients", list(Set(trainingPatients).intersection(Set(testPatients)))
    
    # the routines takes the supplied patient name list and reads from database their gene mutations
    # the result is a dict with patientId for key
    #
    # {
    #    <patient-1> : {
    #                     <gene-1> : <mutaion-1>, // OE or KD
    #                     <gene-2> : <mutaion-2>, // OE or KD
    #                     ...
    #                  }
    #    ...
    # }

    trainingPatientList = readPatients(trainingPatients)
    testPatientList     = readPatients(testPatients)

    if len(trainingPatientList) < len(trainingPatients):
        print "patients missing from database", list(Set(trainingPatients).difference(Set(trainingPatientList.keys())))
        sys.exit(-1)

    calibPatientList = copy.deepcopy(cwgutils.pick(trainingPatientList, calibPatients))

    # ???? we need to provision for loading historical patient list - what is the difference between training and holder list

    # drug specs to be read from 
    # this routine does a lot of reading
    # given the list of names of drugs, it reads all the patientIds
    drugList = readDrugs(drugNames)
    calibrateResponseCoefficients()
    predictResponse()
    # prediction = testPatientResponse(testPatients, testPatientResponse, testPatientMsource, pathwayScoresDir, pathwayTrainingDir, pathwaysForDrug, thresholds[0], thresholds[1])
